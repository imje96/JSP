package com.board.daodto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.board.daodto.MBDAO;

public class MBDAO {
	private DataSource ds;

	public MBDAO() {

		try {
			Context ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/Oracle11g");

			// 커넥션을 사용하는 작업 수행

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// 게시글 목록 가져오기 select 
	public ArrayList<MBDTO> selectAll() {
		ArrayList<MBDTO> dtos = new ArrayList<MBDTO>();

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String query = "SELECT * FROM mvc_board";

		try {
			conn = ds.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				int num = rs.getInt("num");
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				String content = rs.getString("content");
				Timestamp postdate = rs.getTimestamp("postdate");
				int hit = rs.getInt("hit");
				int type = rs.getInt("type");
				int step = rs.getInt("step");
				int indentation = rs.getInt("indentation");

				MBDTO dto = new MBDTO(num, writer, title, content, postdate, hit, type, step, indentation);
				dtos.add(dto);
			}
		} catch (Exception e) {

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return dtos;
	}

	// 게시글 상세조회(특정 글 번호) select 
	public MBDTO selectOne(int num) {
		MBDTO dtos = new MBDTO();
		System.out.println("1");
		System.out.println(num);
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT * FROM mvc_board WHERE num = ?";

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				int newNum = rs.getInt("num");
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				String content = rs.getString("content");
				Timestamp postdate = rs.getTimestamp("postdate");
				int hit = rs.getInt("hit");
				int type = rs.getInt("type");
				int step = rs.getInt("step");
				int indentation = rs.getInt("indentation");

				dtos = new MBDTO(newNum, writer, title, content, postdate, hit, type, step, indentation);
			}
			
			
		} catch (SQLException e) {
		} finally { }

		return dtos;
	}

	// 글쓰기 insert
		public int insertWrite(MBDTO dto) {
			int result = 0;

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String query = "INSERT INTO mvc_board (writer, title, content, hit, type, step, indentation) VALUES(?, ?, ?, ?, ?, ?, ?)";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(query);

				pstmt.setString(1, dto.getWriter());
				pstmt.setString(2, dto.getTitle());
				pstmt.setString(3, dto.getContent());
				pstmt.setInt(4, 0);
				pstmt.setInt(5, dto.getType());
				pstmt.setInt(6, 1);
				pstmt.setInt(7, 0);
				
				pstmt.executeUpdate();
			} catch (Exception e) {
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return result;
		}


	// 수정하기 update
	//hit 조회수는 메서드로 따로 빼서, 상세보기를 눌렀을 때 실행되게끔 할 것 
		public int updateEdit(MBDTO dto) {
			int result = 0;

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String query = "UPDATE mvc_board SET writer = ?, title = ?, content = ?, type = ?, step = ?, indentation = ? ";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(query);

				pstmt.setString(1, dto.getWriter());
				pstmt.setString(2, dto.getTitle());
				pstmt.setString(3, dto.getContent());
				pstmt.setInt(4, dto.getType());
				pstmt.setInt(5, dto.getStep());
				pstmt.setInt(6, dto.getIndentation());
				pstmt.executeUpdate();
				
			} catch (Exception e) {
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return result;
		}
		
	// 삭제하기 delete
		public void deletePost(int num) {

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String query = "DELETE FROM mvc_board WHERE num = ?";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(query);

				pstmt.setInt(1, num);
				pstmt.executeUpdate();
				
			} catch (Exception e) {
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		
	// 조회수 증가하기 	
		
		public void updateHit(int num) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String query = "UPDATE mvc_board SET hit = hit + 1 WHERE num = ?";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(query);
				pstmt.setInt(1, num);
				pstmt.executeUpdate(); // 조회수를 증가시키는 쿼리 실행
				  
				  
			} catch (Exception e) {
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	// 답글 달기
		
		public void replytBoard(MBDTO dto, int id) {
			Connection conn = null;
			PreparedStatement ps = null;
			int result = 0;

			try {
				conn = ds.getConnection();
				String sql = "INSERT INTO mvc_board (writer, title, content, type, step, indentation) "
		                + "VALUES (?, ?, ?, " 
		                + "(SELECT TYPE FROM MVC_BOARD WHERE ID = ?), "
		                + "(SELECT STEP FROM MVC_BOARD WHERE ID = ?)+1, "
		                + "(SELECT INDENTATION FROM MVC_BOARD WHERE ID = ?)+1)";

				ps = conn.prepareStatement(sql);

				ps.setString(1, dto.getWriter());
				ps.setString(2, dto.getTitle());
				ps.setString(3, dto.getContent());
				ps.setInt(4, id);
				ps.setInt(5, id);
				ps.setInt(6, id);

				result = ps.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					conn.close();
					ps.close();
				} catch (SQLException e) {
				}
			}

		}

}
