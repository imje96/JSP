package com.board.daodto;

import java.sql.Timestamp;

public class MBDTO {
	private int num;
	private String writer;
	private String title;
	private String content;
	private Timestamp postdate;
	private int hit;
	private int type;
	private int step;
	private int indentation;
	
	public MBDTO() {
	}
	
	public MBDTO(int num, String writer, String title, String content, Timestamp postdate, int hit, int type, int step,
			int indentation) {
		super();
		this.num = num;
		this.writer = writer;
		this.title = title;
		this.content = content;
		this.postdate = postdate;
		this.hit = hit;
		this.type = type;
		this.step = step;
		this.indentation = indentation;
	}
	
	public MBDTO(String writer, String title, String content, Timestamp regdate, int hit, int type, int step,
			int indentation) {
		super();
		this.writer = writer;
		this.title = title;
		this.content = content;
		this.hit = hit;
		this.type = type;
		this.step = step;
		this.indentation = indentation;
	}

	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getPostdate() {
		return postdate;
	}
	public void setPostdate(Timestamp postdate) {
		this.postdate = postdate;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public int getIndentation() {
		return indentation;
	}
	public void setIndentation(int indentation) {
		this.indentation = indentation;
	}
}
