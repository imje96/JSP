package com.board.command;

import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import com.board.daodto.MBDTO;
import jakarta.servlet.http.HttpServletRequest;

public interface MBcommand {
	void execute(HttpServletRequest request, HttpServletResponse response);

	// SELECT(view)
	public MBDTO selectOne(int num, HttpServletRequest request, HttpServletResponse response);

	// INSERT(write)
	public void insertWrite(MBDTO dto);

	// response뺴기
	// UPDATE(edit)
	public void updateEdit(MBDTO dto);

	// DELETE(delete post)
	public void deletePost(int num);

	// 조회수 증가
	public void updateHit();

	public ArrayList<MBDTO> selectAll(HttpServletRequest request, HttpServletResponse response);

	// 답글 달기
	
	public void replyBoard(MBDTO dto, int num);
}