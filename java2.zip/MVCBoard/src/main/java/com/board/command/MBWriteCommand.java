package com.board.command;

import java.util.ArrayList;

import com.board.daodto.MBDAO;
import com.board.daodto.MBDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class MBWriteCommand implements MBcommand {

	/*
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
	
		String postid = request.getParameter("postid");
		MBDAO dao = new MBDAO();
		MBDTO dto = dao.getContentView(postid);
		
		request.setAttribute("content_view", dto);
	}
	*/
	
	@Override
	public ArrayList<MBDTO> selectAll(HttpServletRequest request, HttpServletResponse response) {
		MBDAO dao = new MBDAO();
		ArrayList<MBDTO> dtos = dao.selectAll();
		request.setAttribute("dtos", dtos);
		return dtos;
	}
	
	@Override
	public MBDTO selectOne(int num, HttpServletRequest request, HttpServletResponse response) {
		MBDAO dao = new MBDAO();
		MBDTO numdto = dao.selectOne(num);
		request.setAttribute("numdto", numdto);
		return numdto;
	}
	
	@Override
	public void insertWrite(MBDTO dto) {
		MBDAO dao = new MBDAO();
		dao.insertWrite(dto);
		
	}
	
	@Override
	public void updateEdit(MBDTO dto) {
		MBDAO dao = new MBDAO();
		dao.updateEdit(dto);
	}
	
	@Override
	public void deletePost(int num) {
		
//		MBDAO dao = new MBDAO();
//	      String[] selectedIds = request.getParameterValues("selectedIds");
		//
		//	      if (selectedIds != null) {
		//	         for (String id : selectedIds) {
		//	        	 dao.deletePost(num);
		//         }
		//      }
		//
		}
	
	@Override
	public void updateHit() {
	}
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		 MBDAO dao = new MBDAO();
		String[] selectedIds = request.getParameterValues("selectedIds");

	      if (selectedIds != null) {
	         for (String id : selectedIds) {
	            dao.deletePost(Integer.parseInt(id));
	         }
	      }
	}

	@Override
	public void replyBoard(MBDTO dto, int num) {
		MBDAO dao = new MBDAO();
		dao.replytBoard(dto,num);
	}
}
