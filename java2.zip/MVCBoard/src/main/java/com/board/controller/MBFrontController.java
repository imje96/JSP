package com.board.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.board.command.MBWriteCommand;
import com.board.command.MBcommand;
import com.board.daodto.MBDAO;
import com.board.daodto.MBDTO;

/**
 * Servlet implementation class MBFrontController
 */
@WebServlet("*.do")
public class MBFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MBFrontController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// doGet(request, response);
		actionDo(request, response);
	}

	private void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("actionDo");

		String uri = request.getRequestURI();
		System.out.println("uri : " + uri);

		String conPath = request.getContextPath();
		System.out.println("conPath : " + conPath);

		String command = uri.substring(conPath.length());
		System.out.println("command : " + command);

		if (command.equals("/selectall.do")) {

			MBWriteCommand mb = new MBWriteCommand();
			mb.selectAll(request, response);
			// 게시글 목록 페이지로 포워딩
			RequestDispatcher dispatcher = request.getRequestDispatcher("View/list_main.jsp");
			dispatcher.forward(request, response);

		} else if (command.equals("/selectone.do")) {
			MBWriteCommand mb = new MBWriteCommand();
			mb.selectOne(0, request, response);
			// 게시글 상세보기 페이지로 포워딩
			RequestDispatcher dispatcher = request.getRequestDispatcher("View/content_view.jsp");
			dispatcher.forward(request, response);

		} else if (command.equals("/insert.do")) {

			String writer = (String) request.getParameter("writer");
			String title = (String) request.getParameter("title");
			String content = (String) request.getParameter("content");
			int type = 0;
			int num = Integer.parseInt(request.getParameter("num"));
			
			// 필요한 값들을 설정한 후에 MBDTO 객체 생성
			MBDTO dto = new MBDTO();
			dto.setWriter(writer);
			dto.setTitle(title);
			dto.setContent(content);
			dto.setType(0);
			dto.setStep(1);
			dto.setIndentation(0);

			MBWriteCommand mb = new MBWriteCommand();
			mb.insertWrite(dto);

			response.sendRedirect("/selectall.do");

			// 게시글 수정 페이지
		} else if (command.equals("/update.do")) {
			String writer = (String) request.getParameter("writer");
			String title = (String) request.getParameter("title");
			String content = (String) request.getParameter("content");
			int type = Integer.parseInt(request.getParameter("type"));
			int step = Integer.parseInt(request.getParameter("step"));
			int indentation = Integer.parseInt(request.getParameter("indentation"));

			// 필요한 값들을 설정한 후에 MBDTO 객체 생성
			MBDTO dto = new MBDTO();
			dto.setWriter(writer);
			dto.setTitle(title);
			dto.setContent(content);
			dto.setType(type);
			dto.setStep(step);
			dto.setIndentation(indentation);

			MBWriteCommand mb = new MBWriteCommand();

			mb.updateEdit(dto);
			response.sendRedirect("/selectall.do");

			// 게시글 삭제 페이지
		} else if (command.equals("/delete.do")) {

			MBWriteCommand mb = new MBWriteCommand();
			mb.execute(request, response);
			response.sendRedirect("/selectall.do");

		}
		else if (command.equals("/reply.do")) {
			//본글 level , indent
		}
		
		else if (command.equals("/reply.do")) {
		    int num = Integer.parseInt(request.getParameter("num"));
		    String writer = request.getParameter("writer");
		    String title = request.getParameter("title");
		    String content = request.getParameter("content");
		    int type = num;
		    int step = Integer.parseInt(request.getParameter("step")) + 1;
		    int indentation = Integer.parseInt(request.getParameter("indentation")) + 1;

		    MBDTO dto = new MBDTO();
		    dto.setWriter(writer);
		    dto.setTitle(title);
		    dto.setContent(content);
		    dto.setType(type);
		    dto.setStep(step);
		    dto.setIndentation(indentation);

		    MBWriteCommand mb = new MBWriteCommand();
		    mb.replyBoard(dto, num);
		    response.sendRedirect("/selectall.do");
		}


	}
}